document.addEventListener('DOMContentLoaded', () => {
    const addToCartForm = document.querySelector('.add-to-cart-form');
    const miniCart = document.getElementById('mini-cart');

    addToCartForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(addToCartForm);

        fetch('/cart/add.js', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success === 1) {
            showSuccessMessage();
            updateMiniCart();
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
        
        setTimeout(() => {
            showSuccessMessage();
            updateMiniCart();
        }, 500);
    });

    function showSuccessMessage() {
        const message = document.createElement('p');
        message.textContent = 'Product added to cart successfully!';
        message.className = 'success-message';
        addToCartForm.appendChild(message);
        setTimeout(() => message.remove(), 3000);
    }

    function updateMiniCart() {
        let currentCount = parseInt(miniCart.dataset.count || '0', 10);
        currentCount++;
        miniCart.dataset.count = currentCount;
        miniCart.textContent = `Cart (${currentCount})`;
    }
});
